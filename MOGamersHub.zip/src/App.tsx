import { Authenticated, Unauthenticated, useQuery } from "convex/react";
import { api } from "../convex/_generated/api";
import { SignInForm } from "./SignInForm";
import { SignOutButton } from "./SignOutButton";
import { Toaster } from "sonner";
import { useState, useEffect } from "react";
import { Store } from "./components/Store";
import { AdminPanel } from "./components/AdminPanel";
import { Cart } from "./components/Cart";
import { CustomerOrders } from "./components/CustomerOrders";

export default function App() {
  const [currentView, setCurrentView] = useState<"store" | "admin" | "orders">("store");
  const [cartItems, setCartItems] = useState<any[]>([]);
  const [showCart, setShowCart] = useState(false);
  const [isTransitioning, setIsTransitioning] = useState(false);
  const [nextView, setNextView] = useState<"store" | "admin" | "orders" | null>(null);
  const isAdmin = useQuery(api.admin.isUserAdmin);
  const currentUser = useQuery(api.admin.getCurrentUser);

  const handleViewChange = (view: "store" | "admin" | "orders") => {
    if (view === currentView) return;
    
    setIsTransitioning(true);
    setNextView(view);
    
    // Wait for slide out animation, then change view
    setTimeout(() => {
      setCurrentView(view);
      setIsTransitioning(false);
      setNextView(null);
    }, 300);
  };

  const addToCart = (product: any) => {
    setCartItems(prev => {
      const existing = prev.find(item => item._id === product._id);
      if (existing) {
        return prev.map(item => 
          item._id === product._id 
            ? { ...item, quantity: item.quantity + 1 }
            : item
        );
      }
      return [...prev, { ...product, quantity: 1 }];
    });
  };

  const removeFromCart = (productId: string) => {
    setCartItems(prev => prev.filter(item => item._id !== productId));
  };

  const updateCartQuantity = (productId: string, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(productId);
      return;
    }
    setCartItems(prev => 
      prev.map(item => 
        item._id === productId ? { ...item, quantity } : item
      )
    );
  };

  return (
    <div className="min-h-screen bg-slate-900">
      <header className="sticky top-0 z-50 bg-slate-900/95 backdrop-blur-sm border-b border-slate-700">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-8">
            <h1 className="text-2xl font-bold bg-gradient-to-r from-blue-400 via-purple-500 to-pink-500 bg-clip-text text-transparent">
              🎮 Mo Gamers Hub
            </h1>
            <nav className="hidden md:flex gap-6">
              <button
                onClick={() => handleViewChange("store")}
                className={`px-4 py-2 rounded-lg transition-all duration-300 transform hover:scale-105 hover-glow ${
                  currentView === "store" 
                    ? "bg-blue-500 text-white" 
                    : "text-gray-300 hover:text-white hover-lift"
                }`}
              >
                🏪 Store
              </button>
              <button
                onClick={() => handleViewChange("orders")}
                className={`px-4 py-2 rounded-lg transition-all duration-300 transform hover:scale-105 hover-glow ${
                  currentView === "orders" 
                    ? "bg-green-500 text-white" 
                    : "text-gray-300 hover:text-white hover-lift"
                }`}
              >
                📦 My Orders
              </button>
              {isAdmin && (
                <button
                  onClick={() => handleViewChange("admin")}
                  className={`px-4 py-2 rounded-lg transition-all duration-300 transform hover:scale-105 hover-glow ${
                    currentView === "admin" 
                      ? "bg-purple-500 text-white" 
                      : "text-gray-300 hover:text-white hover-lift"
                  }`}
                >
                  ⚙️ Admin Panel
                </button>
              )}
            </nav>
          </div>
          
          <div className="flex items-center gap-4">
            <Authenticated>
              <button
                onClick={() => setShowCart(true)}
                className="relative p-2 text-gray-300 hover:text-white transition-all duration-300 transform hover:scale-125 hover-glow"
              >
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 3h2l.4 2M7 13h10l4-8H5.4m0 0L7 13m0 0l-1.5 6M7 13l-1.5 6m0 0h9m-9 0V19a2 2 0 002 2h7a2 2 0 002-2v-.5" />
                </svg>
                {cartItems.length > 0 && (
                  <span className="absolute -top-1 -right-1 bg-pink-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                    {cartItems.reduce((sum, item) => sum + item.quantity, 0)}
                  </span>
                )}
              </button>
            </Authenticated>
            <SignOutButton />
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8 relative overflow-hidden">
        <Unauthenticated>
          <div className="max-w-md mx-auto page-zoom-in">
            <div className="text-center mb-8">
              <h2 className="text-4xl font-bold bg-gradient-to-r from-blue-400 via-purple-500 to-pink-500 bg-clip-text text-transparent mb-4">
                🚀 Level Up Your Gaming
              </h2>
              <p className="text-gray-400">Sign in to access the best gaming deals</p>
            </div>
            <SignInForm />
          </div>
        </Unauthenticated>

        <Authenticated>
          <div className="relative">
            {/* Current view */}
            <div className={`${isTransitioning ? 'page-slide-out-left' : 'page-slide-in-right'}`}>
              {currentView === "store" && !isTransitioning ? (
                <Store addToCart={addToCart} />
              ) : currentView === "admin" && !isTransitioning ? (
                <AdminPanel />
              ) : currentView === "orders" && !isTransitioning ? (
                <CustomerOrders />
              ) : null}
            </div>
            
            {/* Next view during transition */}
            {isTransitioning && nextView && (
              <div className="absolute inset-0 page-slide-in-right">
                {nextView === "store" ? (
                  <Store addToCart={addToCart} />
                ) : nextView === "admin" ? (
                  <AdminPanel />
                ) : nextView === "orders" ? (
                  <CustomerOrders />
                ) : null}
              </div>
            )}
          </div>
        </Authenticated>
      </main>

      {showCart && (
        <Cart
          items={cartItems}
          onClose={() => setShowCart(false)}
          onUpdateQuantity={updateCartQuantity}
          onRemoveItem={removeFromCart}
          onClearCart={() => setCartItems([])}
        />
      )}

      <Toaster />
    </div>
  );
}
