import { useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";

export function ReviewsSection() {
  const reviews = useQuery(api.reviews.getApprovedReviews, {});
  const isAdmin = useQuery(api.admin.isUserAdmin);

  const renderStars = (rating: number) => {
    return (
      <div className="flex gap-1">
        {[1, 2, 3, 4, 5].map((star) => (
          <span
            key={star}
            className={`text-2xl ${star <= rating ? "text-yellow-400" : "text-gray-600"}`}
          >
            ⭐
          </span>
        ))}
      </div>
    );
  };

  return (
    <section className="page-fade-in-up delay-600">
      <div className="text-center mb-8">
        <h2 className="text-4xl font-bold bg-gradient-to-r from-yellow-400 to-orange-500 bg-clip-text text-transparent mb-4">
          ⭐ Customer Reviews ⭐
        </h2>
        <p className="text-gray-400 mb-6">See what our amazing customers have to say!</p>
        
        {!isAdmin && (
          <div className="bg-blue-900/20 border border-blue-500/30 rounded-lg p-4 max-w-md mx-auto">
            <div className="flex items-center gap-2 mb-2">
              <span className="text-blue-400">ℹ️</span>
              <span className="text-blue-400 font-semibold">Reviews by Admin</span>
            </div>
            <p className="text-blue-300 text-sm">
              All reviews are curated and added by our admin team to ensure quality and authenticity.
            </p>
          </div>
        )}
      </div>

      {/* Reviews Display */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {reviews?.map((review, index) => (
          <div 
            key={review._id}
            className={`bg-slate-800 p-6 rounded-xl border border-slate-700 hover-lift hover-glow transition-all duration-500 page-fade-in-up delay-${(index % 6 + 1) * 100}`}
          >
            <div className="flex items-center justify-between mb-4">
              <div>
                <h4 className="font-semibold text-white">{review.customerName}</h4>
                <p className="text-sm text-gray-400">
                  📅 {new Date(review._creationTime).toLocaleDateString()}
                </p>
              </div>
              {renderStars(review.rating)}
            </div>
            
            <p className="text-gray-300 leading-relaxed">
              "{review.comment}"
            </p>
            
            <div className="mt-4 pt-4 border-t border-slate-700">
              <div className="flex items-center gap-2">
                <span className="text-green-400">✅</span>
                <span className="text-sm text-green-400">Verified Customer</span>
              </div>
            </div>
          </div>
        ))}
      </div>

      {reviews && reviews.length === 0 && (
        <div className="text-center py-12 page-zoom-in">
          <div className="text-6xl mb-4">⭐</div>
          <h3 className="text-xl font-semibold text-gray-300 mb-2">No reviews yet</h3>
          <p className="text-gray-500">Our admin team will add customer reviews soon!</p>
        </div>
      )}

      {/* Review Stats */}
      {reviews && reviews.length > 0 && (
        <div className="mt-8 bg-gradient-to-r from-slate-800 to-slate-700 p-6 rounded-xl border border-slate-600 text-center">
          <h3 className="text-xl font-bold text-white mb-4">📊 Customer Satisfaction</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div>
              <div className="text-3xl font-bold text-yellow-400">
                {(reviews.reduce((sum, review) => sum + review.rating, 0) / reviews.length).toFixed(1)}
              </div>
              <div className="text-gray-400">Average Rating</div>
            </div>
            <div>
              <div className="text-3xl font-bold text-blue-400">{reviews.length}</div>
              <div className="text-gray-400">Total Reviews</div>
            </div>
            <div>
              <div className="text-3xl font-bold text-green-400">
                {Math.round((reviews.filter(r => r.rating >= 4).length / reviews.length) * 100)}%
              </div>
              <div className="text-gray-400">Satisfied Customers</div>
            </div>
          </div>
        </div>
      )}
    </section>
  );
}
