import { useState, useEffect } from "react";
import { useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { toast } from "sonner";

interface CartProps {
  items: any[];
  onClose: () => void;
  onUpdateQuantity: (productId: string, quantity: number) => void;
  onRemoveItem: (productId: string) => void;
  onClearCart: () => void;
}

export function Cart({ items, onClose, onUpdateQuantity, onRemoveItem, onClearCart }: CartProps) {
  const [customerName, setCustomerName] = useState("");
  const [customerEmail, setCustomerEmail] = useState("");
  const [customerPhone, setCustomerPhone] = useState("");
  const [paymentMethod, setPaymentMethod] = useState<"instapay" | "vodafone" | "paypal">("instapay");
  const [contactMethod, setContactMethod] = useState<"messenger" | "whatsapp" | "gmail">("whatsapp");
  const [contactValue, setContactValue] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  const createOrder = useMutation(api.orders.createOrder);

  const totalAmount = items.reduce((sum, item) => sum + (item.price * item.quantity), 0);

  const handleSubmitOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!customerName || !customerEmail || !customerPhone || !contactValue || items.length === 0) {
      toast.error("❌ Please fill in all required fields");
      return;
    }

    setIsSubmitting(true);
    try {
      await createOrder({
        customerName,
        customerEmail,
        customerPhone,
        products: items.map(item => ({
          productId: item._id,
          productName: item.name,
          quantity: item.quantity,
          price: item.price,
        })),
        totalAmount,
        paymentMethod,
        contactMethod,
        contactValue,
      });

      toast.success("🎉 Order placed successfully! We'll contact you soon.");
      onClearCart();
      onClose();
    } catch (error) {
      toast.error("❌ Failed to place order. Please try again.");
    } finally {
      setIsSubmitting(false);
    }
  };

  const getContactPlaceholder = () => {
    switch (contactMethod) {
      case "messenger": return "Facebook Messenger username";
      case "whatsapp": return "WhatsApp number (e.g., +201234567890)";
      case "gmail": return "Gmail address";
      default: return "";
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4 cart-slide-in">
      <div className="bg-slate-800 rounded-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto border-2 border-slate-700 page-zoom-in">
        <div className="p-6 border-b border-slate-700 flex items-center justify-between">
          <h2 className="text-2xl font-bold text-white">
            🛒 Shopping Cart
          </h2>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-white transition-all duration-300 transform hover:scale-125 hover:rotate-90"
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        <div className="p-6 space-y-6">
          {items.length === 0 ? (
            <div className="text-center py-8">
              <div className="text-4xl mb-4">🛒</div>
              <p className="text-gray-400">Your cart is empty</p>
            </div>
          ) : (
            <>
              {/* Cart Items */}
              <div className="space-y-4">
                {items.map((item, index) => (
                  <div 
                    key={item._id} 
                    className={`flex items-center gap-4 bg-slate-700 p-4 rounded-lg hover-lift hover-glow transition-all duration-500 page-fade-in-up delay-${(index + 1) * 100}`}
                  >
                    <div className="w-16 h-16 bg-slate-600 rounded-lg flex items-center justify-center text-2xl">
                      {item.category === "xbox" ? "🎯" : 
                       item.category === "playstation" ? "🎲" : "🎫"}
                    </div>
                    
                    <div className="flex-1">
                      <h3 className="font-semibold text-white">{item.name}</h3>
                      <p className="text-gray-400">💰 {item.price} EGP</p>
                    </div>
                    
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => onUpdateQuantity(item._id, item.quantity - 1)}
                        className="w-8 h-8 rounded bg-slate-600 text-white hover:bg-slate-500 transition-all duration-300 transform hover:scale-125"
                      >
                        ➖
                      </button>
                      <span className="w-8 text-center text-white">{item.quantity}</span>
                      <button
                        onClick={() => onUpdateQuantity(item._id, item.quantity + 1)}
                        className="w-8 h-8 rounded bg-slate-600 text-white hover:bg-slate-500 transition-all duration-300 transform hover:scale-125"
                      >
                        ➕
                      </button>
                    </div>
                    
                    <button
                      onClick={() => onRemoveItem(item._id)}
                      className="text-red-400 hover:text-red-300 transition-all duration-300 transform hover:scale-125"
                    >
                      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                      </svg>
                    </button>
                  </div>
                ))}
              </div>

              {/* Order Form */}
              <form onSubmit={handleSubmitOrder} className="space-y-6 page-fade-in-up delay-300">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-3">
                      👤 Full Name *
                    </label>
                    <input
                      type="text"
                      value={customerName}
                      onChange={(e) => setCustomerName(e.target.value)}
                      className="w-full px-4 py-3 bg-slate-700 border border-slate-600 rounded-lg text-white focus:border-blue-500 focus:outline-none transition-all duration-300 hover:scale-105 focus:scale-105 hover-glow"
                      required
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-3">
                      📧 Email Address *
                    </label>
                    <input
                      type="email"
                      value={customerEmail}
                      onChange={(e) => setCustomerEmail(e.target.value)}
                      className="w-full px-4 py-3 bg-slate-700 border border-slate-600 rounded-lg text-white focus:border-blue-500 focus:outline-none transition-all duration-300 hover:scale-105 focus:scale-105 hover-glow"
                      required
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-3">
                    📞 Phone Number *
                  </label>
                  <input
                    type="tel"
                    value={customerPhone}
                    onChange={(e) => setCustomerPhone(e.target.value)}
                    className="w-full px-4 py-3 bg-slate-700 border border-slate-600 rounded-lg text-white focus:border-blue-500 focus:outline-none transition-all duration-300 hover:scale-105 focus:scale-105 hover-glow"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-3">
                    💳 Payment Method *
                  </label>
                  <div className="grid grid-cols-3 gap-2">
                    {[
                      { id: "instapay", name: "InstaPay", icon: "💳" },
                      { id: "vodafone", name: "Vodafone Cash", icon: "📱" },
                      { id: "paypal", name: "PayPal", icon: "💰" },
                    ].map((method) => (
                      <button
                        key={method.id}
                        type="button"
                        onClick={() => setPaymentMethod(method.id as any)}
                        className={`p-3 rounded-lg border transition-all duration-300 transform hover:scale-110 hover-glow ${
                          paymentMethod === method.id
                            ? "border-blue-500 bg-blue-500/20 text-blue-400"
                            : "border-slate-600 bg-slate-700 text-gray-300 hover:border-slate-500 hover-lift"
                        }`}
                      >
                        <div className="text-lg mb-1">{method.icon}</div>
                        <div className="text-xs">{method.name}</div>
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-3">
                    📱 Contact Method *
                  </label>
                  <div className="grid grid-cols-3 gap-2 mb-4">
                    {[
                      { id: "whatsapp", name: "WhatsApp", icon: "📱" },
                      { id: "messenger", name: "Messenger", icon: "💬" },
                      { id: "gmail", name: "Gmail", icon: "📧" },
                    ].map((method) => (
                      <button
                        key={method.id}
                        type="button"
                        onClick={() => setContactMethod(method.id as any)}
                        className={`p-3 rounded-lg border transition-all duration-300 transform hover:scale-110 hover-glow ${
                          contactMethod === method.id
                            ? "border-purple-500 bg-purple-500/20 text-purple-400"
                            : "border-slate-600 bg-slate-700 text-gray-300 hover:border-slate-500 hover-lift"
                        }`}
                      >
                        <div className="text-lg mb-1">{method.icon}</div>
                        <div className="text-xs">{method.name}</div>
                      </button>
                    ))}
                  </div>
                  <input
                    type="text"
                    value={contactValue}
                    onChange={(e) => setContactValue(e.target.value)}
                    placeholder={getContactPlaceholder()}
                    className="w-full px-4 py-3 bg-slate-700 border border-slate-600 rounded-lg text-white focus:border-purple-500 focus:outline-none transition-all duration-300 hover:scale-105 focus:scale-105 hover-glow"
                    required
                  />
                </div>

                <div className="border-t border-slate-700 pt-4">
                  <div className="bg-red-900/20 border border-red-500/30 rounded-lg p-4 mb-4">
                    <div className="flex items-center gap-2 mb-2">
                      <span className="text-red-400">⚠️</span>
                      <span className="text-red-400 font-semibold">No Returns Policy</span>
                    </div>
                    <p className="text-red-300 text-sm">
                      All sales are final. Digital products cannot be returned or refunded once delivered. 
                      Please review your order carefully before placing it.
                    </p>
                  </div>
                  
                  <div className="flex justify-between items-center mb-4">
                    <span className="text-xl font-bold text-white">
                      💰 Total: {totalAmount.toFixed(2)} EGP
                    </span>
                  </div>
                  
                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className={`w-full bg-gradient-to-r from-blue-500 to-purple-500 text-white font-semibold py-4 rounded-lg hover:from-blue-600 hover:to-purple-600 transition-all duration-300 transform hover:scale-105 hover-glow disabled:opacity-50 disabled:cursor-not-allowed`}
                  >
                    {isSubmitting ? (
                      <span className="flex items-center justify-center gap-2">
                        <span>⚡</span>
                        Placing Order...
                      </span>
                    ) : (
                      <span className="flex items-center justify-center gap-2">
                        🚀 Place Order
                      </span>
                    )}
                  </button>
                </div>
              </form>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
