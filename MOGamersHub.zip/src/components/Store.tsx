import { useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";
import { ProductCard } from "./ProductCard";
import { ReviewsSection } from "./ReviewsSection";
import { useState } from "react";

interface StoreProps {
  addToCart: (product: any) => void;
}

export function Store({ addToCart }: StoreProps) {
  const [selectedCategory, setSelectedCategory] = useState<"all" | "playstation" | "xbox" | "codes" | "others">("all");
  
  const products = useQuery(api.products.listProducts, 
    selectedCategory === "all" ? {} : { category: selectedCategory }
  );
  const featuredProducts = useQuery(api.products.getFeaturedProducts);

  const categories = [
    { id: "all", name: "All Products", icon: "🎮" },
    { id: "playstation", name: "PlayStation", icon: "🎲" },
    { id: "xbox", name: "Xbox", icon: "🎯" },
    { id: "codes", name: "Game Codes", icon: "🎫" },
    { id: "others", name: "Others", icon: "📦" },
  ];

  return (
    <div className="space-y-12">
      {/* Hero Section */}
      <div className="text-center space-y-8 page-fade-in-down">
        <div className="relative">
          <h1 className="text-5xl md:text-7xl font-bold bg-gradient-to-r from-blue-400 via-purple-500 to-pink-500 bg-clip-text text-transparent mb-4">
            🎮 Mo Gamers Hub 🎮
          </h1>
          <div className="absolute -top-4 -right-4 animate-bounce">
            <a 
              href="https://www.facebook.com/profile.php?id=100095347969665" 
              target="_blank" 
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-full transition-all duration-300 transform hover:scale-110 hover-glow"
            >
              <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
              </svg>
              Follow Us
            </a>
          </div>
        </div>
        
        <p className="text-xl text-gray-300 max-w-2xl mx-auto">
          🚀 Your ultimate destination for PlayStation, Xbox, and digital game codes! 
          Fast delivery, great prices, and 24/7 support! 🎯
        </p>
        
        {/* Enhanced Feature Boxes */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 max-w-6xl mx-auto mt-12">
          {[
            { number: "1000+", text: "Products Available", color: "blue", icon: "📦" },
            { number: "24/7", text: "Customer Support", color: "green", icon: "🎧" },
            { number: "⚡", text: "Instant Delivery", color: "purple", icon: "🚀" },
            { number: "100%", text: "Secure Payment", color: "pink", icon: "🔒" }
          ].map((feature, index) => (
            <div 
              key={index}
              className={`bg-slate-800 p-6 rounded-xl border border-slate-700 hover-lift hover-glow transition-all duration-500 page-fade-in-up delay-${(index + 1) * 100}`}
            >
              <div className="text-4xl mb-3">{feature.icon}</div>
              <div className={`text-2xl font-bold text-${feature.color}-400 mb-2`}>
                {feature.number}
              </div>
              <div className="text-gray-300 text-sm">{feature.text}</div>
            </div>
          ))}
        </div>

        {/* Gaming Stats */}
        <div className="bg-gradient-to-r from-slate-800 to-slate-700 p-8 rounded-2xl border border-slate-600 max-w-4xl mx-auto page-zoom-in delay-300">
          <h3 className="text-2xl font-bold text-white mb-6">🏆 Why Choose Mo Gamers Hub?</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="text-center">
              <div className="text-3xl mb-2">⭐</div>
              <div className="text-lg font-semibold text-yellow-400">5-Star Reviews</div>
              <div className="text-gray-400">Trusted by gamers</div>
            </div>
            <div className="text-center">
              <div className="text-3xl mb-2">🎮</div>
              <div className="text-lg font-semibold text-blue-400">Top Platforms</div>
              <div className="text-gray-400">PlayStation, Xbox, Codes</div>
            </div>
            <div className="text-center">
              <div className="text-3xl mb-2">💎</div>
              <div className="text-lg font-semibold text-purple-400">Premium Quality</div>
              <div className="text-gray-400">Original products only</div>
            </div>
          </div>
        </div>
      </div>

      {/* Featured Products */}
      {featuredProducts && featuredProducts.length > 0 && (
        <section className="page-fade-in-up delay-300">
          <div className="text-center mb-8">
            <h2 className="text-4xl font-bold bg-gradient-to-r from-yellow-400 to-orange-500 bg-clip-text text-transparent mb-4">
              ⭐ Featured Products ⭐
            </h2>
            <p className="text-gray-400">Hand-picked deals you don't want to miss!</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {featuredProducts.map((product, index) => (
              <div 
                key={product._id}
                className={`page-zoom-in delay-${(index + 1) * 100}`}
              >
                <ProductCard
                  product={product}
                  onAddToCart={addToCart}
                  featured
                />
              </div>
            ))}
          </div>
        </section>
      )}

      {/* Category Filter */}
      <div className="page-fade-in-down delay-400">
        <h2 className="text-3xl font-bold text-white text-center mb-8">
          🎯 Browse by Category
        </h2>
        <div className="flex flex-wrap gap-4 justify-center">
          {categories.map((category, index) => (
            <button
              key={category.id}
              onClick={() => setSelectedCategory(category.id as any)}
              className={`px-6 py-4 rounded-xl font-semibold transition-all duration-300 transform hover:scale-110 hover-glow ${
                selectedCategory === category.id
                  ? "bg-gradient-to-r from-blue-500 to-purple-500 text-white shadow-lg"
                  : "bg-slate-800 text-gray-300 hover:bg-slate-700 hover-lift border border-slate-600"
              }`}
            >
              <div className="flex flex-col items-center gap-2">
                <span className="text-2xl">{category.icon}</span>
                <span className="text-sm">{category.name}</span>
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Products Grid */}
      <section>
        <div className="text-center mb-8">
          <h2 className="text-3xl font-bold text-white mb-2">
            🛒 {selectedCategory === "all" ? "All Products" : categories.find(c => c.id === selectedCategory)?.name}
          </h2>
          <p className="text-gray-400">
            {products?.length || 0} products available
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {products?.map((product, index) => (
            <div 
              key={product._id}
              className={`page-bounce-in delay-${(index % 8 + 1) * 100}`}
            >
              <ProductCard
                product={product}
                onAddToCart={addToCart}
              />
            </div>
          ))}
        </div>
        
        {products && products.length === 0 && (
          <div className="text-center py-12 page-zoom-in">
            <div className="text-6xl mb-4">🎮</div>
            <h3 className="text-xl font-semibold text-gray-300 mb-2">No products found</h3>
            <p className="text-gray-500">Check back later for new arrivals!</p>
          </div>
        )}
      </section>

      {/* Reviews Section */}
      <ReviewsSection />

      {/* Call to Action */}
      <div className="bg-gradient-to-r from-blue-900 to-purple-900 p-8 rounded-2xl text-center page-fade-in-up delay-500">
        <h3 className="text-3xl font-bold text-white mb-4">🎮 Ready to Level Up?</h3>
        <p className="text-gray-300 mb-6 max-w-2xl mx-auto">
          Join thousands of satisfied gamers who trust Mo Gamers Hub for their gaming needs. 
          Fast delivery, competitive prices, and excellent customer service guaranteed!
        </p>
        <div className="flex flex-wrap gap-4 justify-center">
          <a 
            href="https://www.facebook.com/profile.php?id=100095347969665" 
            target="_blank" 
            rel="noopener noreferrer"
            className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-lg transition-all duration-300 transform hover:scale-105 hover-glow"
          >
            📱 Contact Us on Facebook
          </a>
          <button 
            onClick={() => setSelectedCategory("codes")}
            className="bg-purple-600 hover:bg-purple-700 text-white px-6 py-3 rounded-lg transition-all duration-300 transform hover:scale-105 hover-glow"
          >
            🎫 Browse Game Codes
          </button>
        </div>
      </div>
    </div>
  );
}
