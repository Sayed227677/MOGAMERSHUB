import { useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";

export function CustomerOrders() {
  const orders = useQuery(api.orders.getCustomerOrders);

  const getStatusColor = (status: string) => {
    switch (status) {
      case "pending": return "bg-yellow-500/20 text-yellow-400";
      case "confirmed": return "bg-blue-500/20 text-blue-400";
      case "shipped": return "bg-purple-500/20 text-purple-400";
      case "delivered": return "bg-green-500/20 text-green-400";
      default: return "bg-gray-500/20 text-gray-400";
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "pending": return "⏳";
      case "confirmed": return "✅";
      case "shipped": return "🚚";
      case "delivered": return "📦";
      default: return "❓";
    }
  };

  return (
    <div className="space-y-8">
      <div className="text-center page-fade-in-down">
        <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-400 via-purple-500 to-pink-500 bg-clip-text text-transparent mb-4">
          📦 My Orders
        </h1>
        <p className="text-gray-400">Track your gaming purchases and delivery status</p>
      </div>

      <div className="space-y-6 page-fade-in-up delay-200">
        {orders === undefined ? (
          <div className="text-center py-12">
            <div className="text-4xl mb-4">⏳</div>
            <p className="text-gray-400">Loading your orders...</p>
          </div>
        ) : orders.length === 0 ? (
          <div className="text-center py-12 page-zoom-in">
            <div className="text-6xl mb-4">🛒</div>
            <h3 className="text-xl font-semibold text-gray-300 mb-2">No orders yet</h3>
            <p className="text-gray-500">Start shopping to see your orders here!</p>
          </div>
        ) : (
          orders.map((order: any, index: number) => (
            <div 
              key={order._id} 
              className={`bg-slate-800 p-6 rounded-xl border border-slate-700 hover-lift hover-glow transition-all duration-500 page-fade-in-up delay-${(index % 5 + 1) * 100}`}
            >
              <div className="flex justify-between items-start mb-4">
                <div>
                  <h3 className="font-semibold text-white mb-2">
                    Order #{order._id.slice(-8).toUpperCase()}
                  </h3>
                  <p className="text-sm text-gray-400">
                    📅 {new Date(order._creationTime).toLocaleDateString('en-US', {
                      year: 'numeric',
                      month: 'long',
                      day: 'numeric',
                      hour: '2-digit',
                      minute: '2-digit'
                    })}
                  </p>
                </div>
                <div className="text-right">
                  <div className={`px-3 py-1 rounded-full text-sm font-semibold ${getStatusColor(order.status)}`}>
                    {getStatusIcon(order.status)} {order.status.toUpperCase()}
                  </div>
                  <p className="text-lg font-bold text-white mt-2">💰 {order.totalAmount} EGP</p>
                  <p className="text-sm text-gray-400 capitalize">💳 {order.paymentMethod}</p>
                </div>
              </div>
              
              <div className="mb-4">
                <h4 className="text-sm font-semibold text-gray-300 mb-2">🛒 Products:</h4>
                <div className="space-y-2">
                  {order.products.map((product: any, index: number) => (
                    <div key={index} className="flex items-center justify-between bg-slate-700 p-3 rounded-lg">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-slate-600 rounded-lg flex items-center justify-center text-lg">
                          🎮
                        </div>
                        <div>
                          <p className="text-white font-medium">{product.productName}</p>
                          <p className="text-gray-400 text-sm">Quantity: {product.quantity}</p>
                        </div>
                      </div>
                      <span className="text-white font-semibold">
                        {(product.price * product.quantity).toFixed(2)} EGP
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="border-t border-slate-700 pt-4">
                <div className="flex justify-between items-center">
                  <div className="text-sm text-gray-400">
                    📱 Contact: {order.contactMethod} - {order.contactValue}
                  </div>
                  <div className="text-right">
                    <p className="text-sm text-gray-400">Total Amount</p>
                    <p className="text-xl font-bold text-white">{order.totalAmount} EGP</p>
                  </div>
                </div>
              </div>

              {order.status === "delivered" && (
                <div className="mt-4 bg-green-900/20 border border-green-500/30 rounded-lg p-3">
                  <div className="flex items-center gap-2">
                    <span className="text-green-400">✅</span>
                    <span className="text-green-400 font-semibold">Order Delivered</span>
                  </div>
                  <p className="text-green-300 text-sm mt-1">
                    Your order has been successfully delivered. Thank you for shopping with us!
                  </p>
                </div>
              )}
            </div>
          ))
        )}
      </div>
    </div>
  );
}
