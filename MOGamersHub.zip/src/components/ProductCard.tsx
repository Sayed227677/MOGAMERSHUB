import { useState } from "react";

interface ProductCardProps {
  product: {
    _id: string;
    name: string;
    description: string;
    price: number;
    category: string;
    imageUrl?: string;
    inStock: boolean;
  };
  onAddToCart: (product: any) => void;
  featured?: boolean;
}

export function ProductCard({ product, onAddToCart, featured }: ProductCardProps) {
  const [isAdding, setIsAdding] = useState(false);

  const getCategoryBadge = (category: string) => {
    switch (category) {
      case "xbox": return "bg-green-500/20 text-green-400";
      case "playstation": return "bg-blue-500/20 text-blue-400";
      case "codes": return "bg-yellow-500/20 text-yellow-400";
      case "others": return "bg-gray-500/20 text-gray-400";
      default: return "bg-gray-500/20 text-gray-400";
    }
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case "xbox": return "🎯";
      case "playstation": return "🎲";
      case "codes": return "🎫";
      case "others": return "📦";
      default: return "🎮";
    }
  };

  const handleAddToCart = async () => {
    setIsAdding(true);
    onAddToCart(product);
    
    setTimeout(() => {
      setIsAdding(false);
    }, 1000);
  };

  return (
    <div 
      className={`bg-slate-800 rounded-xl overflow-hidden border border-slate-700 hover:border-slate-600 transition-all duration-500 group hover-lift hover-glow ${
        featured ? "ring-2 ring-gradient-to-r from-yellow-400 to-orange-500" : ""
      }`}
    >
      {featured && (
        <div className="bg-gradient-to-r from-yellow-500 to-orange-500 text-white text-xs font-bold px-3 py-1 text-center animate-pulse">
          ⭐ FEATURED DEAL ⭐
        </div>
      )}
      
      <div className="aspect-video bg-slate-700 relative overflow-hidden">
        {product.imageUrl ? (
          <img
            src={product.imageUrl}
            alt={product.name}
            className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center text-4xl transition-all duration-500 group-hover:text-6xl group-hover:rotate-12">
            {getCategoryIcon(product.category)}
          </div>
        )}
        
        <div className={`absolute top-2 right-2 px-2 py-1 rounded text-xs font-semibold transition-all duration-300 ${getCategoryBadge(product.category)} group-hover:scale-110`}>
          {product.category.toUpperCase()}
        </div>

        {!product.inStock && (
          <div className="absolute inset-0 bg-black/60 flex items-center justify-center">
            <span className="bg-red-500 text-white px-3 py-1 rounded-full text-sm font-bold">
              ❌ OUT OF STOCK
            </span>
          </div>
        )}
      </div>
      
      <div className="p-4 space-y-3">
        <h3 className="font-semibold text-white group-hover:text-blue-400 transition-all duration-300 line-clamp-2">
          {product.name}
        </h3>
        
        <p className="text-sm text-gray-400 line-clamp-2 transition-all duration-300 group-hover:text-gray-300">
          {product.description}
        </p>
        
        <div className="flex items-center justify-between">
          <div className="text-xl font-bold text-white transition-all duration-300 group-hover:text-green-400">
            💰 {product.price} EGP
          </div>
          
          <button
            onClick={handleAddToCart}
            disabled={!product.inStock}
            className={`px-4 py-2 rounded-lg font-semibold transition-all duration-500 transform hover:scale-110 hover-glow ${
              product.inStock
                ? `bg-gradient-to-r from-blue-500 to-purple-500 text-white hover:from-blue-600 hover:to-purple-600 ${
                    isAdding ? 'bg-green-500 scale-110' : ''
                  }`
                : "bg-gray-600 text-gray-400 cursor-not-allowed opacity-50"
            }`}
          >
            {isAdding ? (
              <span className="flex items-center gap-2">
                <span className="animate-spin">⚡</span>
                Adding...
              </span>
            ) : product.inStock ? (
              <span className="flex items-center gap-2">
                🛒 Add to Cart
              </span>
            ) : (
              "❌ Out of Stock"
            )}
          </button>
        </div>
      </div>
    </div>
  );
}
