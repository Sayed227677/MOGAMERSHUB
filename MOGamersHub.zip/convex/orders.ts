import { query, mutation } from "./_generated/server";
import { v } from "convex/values";
import { getAuthUserId } from "@convex-dev/auth/server";

// Check if user is admin
async function isAdmin(ctx: any) {
  const userId = await getAuthUserId(ctx);
  if (!userId) return false;
  
  const user = await ctx.db.get(userId);
  if (!user?.email) return false;
  
  // Check if the email is the admin email
  return user.email === "admin@mogamershub.com";
}

export const createOrder = mutation({
  args: {
    customerName: v.string(),
    customerEmail: v.string(),
    customerPhone: v.string(),
    products: v.array(v.object({
      productId: v.id("products"),
      productName: v.string(),
      quantity: v.number(),
      price: v.number(),
    })),
    totalAmount: v.number(),
    paymentMethod: v.union(v.literal("instapay"), v.literal("vodafone"), v.literal("paypal")),
    contactMethod: v.union(v.literal("messenger"), v.literal("whatsapp"), v.literal("gmail")),
    contactValue: v.string(),
  },
  handler: async (ctx, args) => {
    return await ctx.db.insert("orders", {
      ...args,
      status: "pending",
    });
  },
});

export const listOrders = query({
  args: { status: v.optional(v.union(v.literal("pending"), v.literal("confirmed"), v.literal("shipped"), v.literal("delivered"))) },
  handler: async (ctx, args) => {
    if (!(await isAdmin(ctx))) {
      throw new Error("Unauthorized");
    }
    
    if (args.status) {
      return await ctx.db
        .query("orders")
        .withIndex("by_status", (q) => q.eq("status", args.status!))
        .order("desc")
        .collect();
    }
    
    return await ctx.db.query("orders").order("desc").collect();
  },
});

export const updateOrderStatus = mutation({
  args: {
    orderId: v.id("orders"),
    status: v.union(v.literal("pending"), v.literal("confirmed"), v.literal("shipped"), v.literal("delivered")),
  },
  handler: async (ctx, args) => {
    if (!(await isAdmin(ctx))) {
      throw new Error("Unauthorized");
    }
    
    await ctx.db.patch(args.orderId, { status: args.status });
  },
});

export const getCustomerOrders = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Not authenticated");
    }
    
    const user = await ctx.db.get(userId);
    if (!user?.email) {
      return [];
    }
    
    // Get orders by customer email
    return await ctx.db
      .query("orders")
      .filter((q) => q.eq(q.field("customerEmail"), user.email))
      .order("desc")
      .collect();
  },
});
