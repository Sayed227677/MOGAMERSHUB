import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";
import { authTables } from "@convex-dev/auth/server";

const applicationTables = {
  products: defineTable({
    name: v.string(),
    description: v.string(),
    price: v.number(),
    category: v.union(
      v.literal("playstation"), 
      v.literal("xbox"), 
      v.literal("codes"), 
      v.literal("others")
    ),
    imageUrl: v.optional(v.string()),
    inStock: v.boolean(),
    featured: v.optional(v.boolean()),
  }).index("by_category", ["category"]),

  orders: defineTable({
    customerName: v.string(),
    customerEmail: v.optional(v.string()),
    customerPhone: v.string(),
    products: v.array(v.object({
      productId: v.id("products"),
      productName: v.string(),
      quantity: v.number(),
      price: v.number(),
    })),
    totalAmount: v.number(),
    paymentMethod: v.union(
      v.literal("instapay"), 
      v.literal("vodafone"), 
      v.literal("paypal")
    ),
    status: v.union(
      v.literal("pending"), 
      v.literal("confirmed"), 
      v.literal("shipped"), 
      v.literal("delivered")
    ),
    contactMethod: v.union(
      v.literal("messenger"), 
      v.literal("whatsapp"), 
      v.literal("gmail")
    ),
    contactValue: v.string(),
  }).index("by_status", ["status"]),

  reviews: defineTable({
    customerName: v.string(),
    customerEmail: v.string(),
    rating: v.number(), // 1-5 stars
    comment: v.string(),
    productId: v.optional(v.id("products")),
    approved: v.boolean(),
  }).index("by_approved", ["approved"])
    .index("by_product", ["productId"]),
};

export default defineSchema({
  ...authTables,
  ...applicationTables,
});
