import { query, mutation } from "./_generated/server";
import { v } from "convex/values";
import { getAuthUserId } from "@convex-dev/auth/server";

// Check if user is admin
async function isAdmin(ctx: any) {
  const userId = await getAuthUserId(ctx);
  if (!userId) return false;
  
  const user = await ctx.db.get(userId);
  if (!user?.email) return false;
  
  return user.email === "admin@mogamershub.com";
}

export const addReview = mutation({
  args: {
    customerName: v.string(),
    customerEmail: v.string(),
    rating: v.number(),
    comment: v.string(),
    productId: v.optional(v.id("products")),
  },
  handler: async (ctx, args) => {
    // Only admins can add reviews
    if (!(await isAdmin(ctx))) {
      throw new Error("Unauthorized - Only admins can add reviews");
    }
    
    // Validate rating is between 1-5
    if (args.rating < 1 || args.rating > 5) {
      throw new Error("Rating must be between 1 and 5");
    }
    
    return await ctx.db.insert("reviews", {
      ...args,
      approved: true, // Admin-added reviews are automatically approved
    });
  },
});

export const getApprovedReviews = query({
  args: { productId: v.optional(v.id("products")) },
  handler: async (ctx, args) => {
    if (args.productId) {
      return await ctx.db
        .query("reviews")
        .withIndex("by_product", (q) => q.eq("productId", args.productId!))
        .filter((q) => q.eq(q.field("approved"), true))
        .order("desc")
        .collect();
    }
    
    return await ctx.db
      .query("reviews")
      .withIndex("by_approved", (q) => q.eq("approved", true))
      .order("desc")
      .take(10);
  },
});

export const getAllReviews = query({
  args: {},
  handler: async (ctx) => {
    if (!(await isAdmin(ctx))) {
      throw new Error("Unauthorized");
    }
    
    return await ctx.db.query("reviews").order("desc").collect();
  },
});

export const approveReview = mutation({
  args: { reviewId: v.id("reviews") },
  handler: async (ctx, args) => {
    if (!(await isAdmin(ctx))) {
      throw new Error("Unauthorized");
    }
    
    await ctx.db.patch(args.reviewId, { approved: true });
  },
});

export const deleteReview = mutation({
  args: { reviewId: v.id("reviews") },
  handler: async (ctx, args) => {
    if (!(await isAdmin(ctx))) {
      throw new Error("Unauthorized");
    }
    
    await ctx.db.delete(args.reviewId);
  },
});
